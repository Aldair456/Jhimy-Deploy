import os
from pymongo import MongoClient
from bson import ObjectId
from utils.response import Response
from utils.serializable import serialize_document

# Solo local
os.environ['DATABASE_URL'] = "mongodb+srv://admin:gJ66UV7FD1qs6jG0@valetest.8gw0zdt.mongodb.net"
os.environ['MY_DATABASE_NAME'] = "vera-app"

# Conexión global a MongoDB (se reutiliza entre invocaciones)
client = MongoClient(os.environ['DATABASE_URL'], serverSelectionTimeoutMS=5000)
db = client[os.environ['MY_DATABASE_NAME']]

def handler_function(event, context):

    """
        GET handler para obtener la información de un analista, incluyendo sus assignedBusinesses.
        Se espera que event["pathParameters"]["id"] contenga el id del analista.
    """
    try:
        path_params = event.get("pathParameters", {})
        analyst_id = path_params.get("id")
        if not analyst_id:
            return Response(
                status_code=400,
                body={"error": "Falta el parámetro 'id'"}
            ).to_dict()

        # Si se almacena _id como ObjectId, convertir:
        # analyst = db["User"].find_one({"_id": ObjectId(analyst_id)})
        # Si se almacena como string:
        analyst = db["User"].find_one({"_id": ObjectId(analyst_id)})
        if not analyst:
            return Response(
                status_code=404,
                body={"error": "Usuario no encontrado"}
            ).to_dict()

        analyst_serializer  = serialize_document(analyst)
        if "password" in analyst_serializer:
            del analyst_serializer["password"]
        return Response(
            status_code=200,
            body={"data": analyst_serializer}
        ).to_dict()
    except Exception as e:
        return Response(
            status_code=500,
            body={"error": "Error interno", "details": str(e)}
        ).to_dict()
if __name__ == "__main__":
    event = {
        "pathParameters": {
            "id": "67c8a92b6f161af2d28af65b",
        }    }
    print(handler_function(event=event, context=None))
