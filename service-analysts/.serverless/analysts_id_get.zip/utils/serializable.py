import datetime
from bson import ObjectId


def serialize_document(doc):
    """
    Recibe un objeto (diccionario, lista, etc.) y lo transforma en uno
    que sea serializable a JSON, convirtiendo ObjectId a string y datetime a formato ISO.
    """
    if isinstance(doc, list):
        return [serialize_document(item) for item in doc]

    if isinstance(doc, dict):
        return {key: serialize_document(value) for key, value in doc.items()}

    if isinstance(doc, ObjectId):
        return str(doc)

    if isinstance(doc, datetime.datetime):
        return doc.isoformat()

    # Otros tipos (enteros, cadenas, etc.) se retornan sin modificar.
    return doc

