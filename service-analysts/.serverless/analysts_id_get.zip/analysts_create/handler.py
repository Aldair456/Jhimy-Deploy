"""
Este módulo implementa una función Lambda para crear un usuario analista en MongoDB,
basándose en la autenticación mediante JWT.

La función lambda_handler:
- Extrae el token JWT de la cabecera "Authorization" (formato "Bearer <token>").
- Decodifica el token para obtener la sesión del usuario.
- Verifica que la sesión exista y que el usuario tenga rol "ADMIN".
- Extrae del cuerpo (body) de la solicitud los datos: username, password, name, email.
- Crea un nuevo usuario con rol "ANALYST" en la colección "users", usando el evaluatorId de la sesión.
- Devuelve una respuesta HTTP con el usuario creado o errores apropiados.

Variables de entorno necesarias:
- DATABASE_URL: URL de conexión a MongoDB.
- JWT_SECRET: Clave secreta para decodificar y firmar el token JWT.
"""

import os
import json
import datetime
from bson import ObjectId
from pymongo import MongoClient,errors
import jwt  # Asegúrate de tener instalado PyJWT
from utils.response import Response
from utils.serializable import serialize_document

#solo local
os.environ['DATABASE_URL'] = "mongodb+srv://admin:gJ66UV7FD1qs6jG0@valetest.8gw0zdt.mongodb.net"
os.environ['MY_DATABASE_NAME'] = "vera-app"

# Conexión global a MongoDB (se reutiliza entre invocaciones)
client = MongoClient(os.environ['DATABASE_URL'], serverSelectionTimeoutMS=5000)
db =  client[os.environ['MY_DATABASE_NAME']]

# Clave secreta para decodificar y firmar el token JWT
SECRET_KEY = os.environ.get("JWT_SECRET", "supersecret")


def handler_function(event, context):
    """
    Función Lambda para crear un usuario analista.

    Parámetros:
        event (dict): Objeto de evento que contiene la solicitud HTTP. Se espera:
                      - Headers: Debe incluir "Authorization" con el token JWT (formato "Bearer <token>").
                      - Body: Un JSON con 'username', 'password', 'name' y 'email'.
        context (object): Información del contexto de ejecución de Lambda.

    Retorna:
        dict: Respuesta HTTP en formato JSON con el estado y mensaje.
              - Código 200: Creación exitosa del analista.
              - Código 400: Errores en la solicitud (body o datos faltantes).
              - Código 401: Usuario no autorizado (token inválido o rol distinto a ADMIN).
              - Código 500: Error interno del servidor.
    """
    try:
        # Extraer y validar el token JWT de la cabecera Authorization
        headers = event.get("headers", {})
        auth_header = headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return Response(
                status_code=401,
                body={"error": "Authorization header missing or malformed"}
            ).to_dict()
        token = auth_header.split(" ", 1)[1]

        try:
            # Decodificar el token JWT
            session = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        except Exception as e:
            return Response(
                status_code=401,
                body={"error": "Token inválido", "details": str(e)}
            ).to_dict()

        # Verificar que el usuario autenticado tenga rol "ADMIN"
        if session.get("role") != "ADMIN":
            return Response(
                status_code=401,
                body={"error": "Unauthorized: se requiere rol ADMIN"}
            ).to_dict()

        # Extraer evaluatorId de la sesión
        evaluatorId = session.get("evaluatorId")
        if not evaluatorId:
            return Response(
                status_code=400,
                body={"error": "Evaluator ID no encontrado en la sesión"}
            ).to_dict()

        # Parsear el cuerpo de la solicitud (se espera en formato JSON)
        body = event.get("body")
        if not body:
            return Response(
                status_code=400,
                body={"error": "Falta el cuerpo de la solicitud"}
            ).to_dict()
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                return Response(
                    status_code=400,
                    body={"error": "El cuerpo no es un JSON válido"}
                ).to_dict()

        required_fields = ["username", "password", "name", "email"]
        missing_fields = []

        for field in required_fields:
            value = body.get(field)
            if not value or not str(value).strip():
                missing_fields.append(field)

        if missing_fields:
            return Response(
                status_code=400,
                body={
                    "error": f"Los siguientes campos son requeridos y no pueden estar vacíos: {', '.join(missing_fields)}"
                }
            ).to_dict()
        username = body.get("username")
        password = body.get("password")
        name = body.get("name")
        email = body.get("email")


        # Crear el analista (usuario con rol ANALYST) en la colección "users"
        new_user_data = {
            "username": username,
            "password": password,  # En producción, se deben hashear las contraseñas
            "role": "ANALYST",
            "evaluatorId": ObjectId(evaluatorId),
            "name": name,
            "email": email,
            "createdAt": datetime.datetime.utcnow(),
            "updatedAt": datetime.datetime.utcnow()
        }



        try:
            result = db["User"].insert_one(new_user_data)
        except errors.DuplicateKeyError:
            # Si se viola la restricción de índice único, retorna un error 409 Conflict
            return Response(
                status_code=409,
                body={"error": "El usuario ya existe"}
            ).to_dict()

        new_user_serializer = serialize_document(new_user_data)
        if "password" in new_user_serializer:
            del new_user_serializer["password"]

        return Response(
            status_code=200,
            body={"data": new_user_serializer}
        ).to_dict()

    except Exception as e:
        return Response(
            status_code=500,
            body={"error": "Error interno del servidor", "details": str(e)}
        ).to_dict()


# Bloque opcional para pruebas locales
if __name__ == "__main__":
    # Simular headers con un token JWT para un usuario ADMIN
    # En este ejemplo, generamos un token para pruebas (valido por 30 días)

    test_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY3OWQwNTA4YzQzNGQ3YzJjOTNiM2EwZCIsInVzZXJuYW1lIjoicmJvbmlmYXoiLCJyb2xlIjoiQURNSU4iLCJldmFsdWF0b3JJZCI6IjY3OWQwNGQyYzQzNGQ3YzJjOTNiM2EwOSIsImV4cCI6MTc0MzgwMDE5Mn0.zwm2zAB7SEoo3rlv_km8y3mOw1u0pzNqFzSMUXvnE1w"
    test_headers = {
        "Authorization": f"Bearer {test_token}"
    }

    # Simular un body de solicitud para crear un analista
    test_body = {
        "username": "analystUser6",
        "password": "analystPassword",
        "name": "Analyst Name",
        "email": "analyst@example.com"
    }

    # Evento de prueba
    event_test = {
        "headers": test_headers,
        "body": json.dumps(test_body)
    }

    # Ejecutar la función Lambda de prueba
    response = handler_function(event_test, {})
    print("Respuesta de la función Lambda:")
    print(response)
