"""
Este módulo implementa una función Lambda para asignar un negocio a un analista.

La función lambda_handler:
- Extrae el parámetro de ruta "id" que representa el id del analista.
- Parsea el cuerpo de la solicitud (JSON) para obtener "businessId".
- Actualiza el documento del analista en la colección "users", agregando businessId al arreglo "assignedBusinessIds".
- Actualiza el documento del negocio en la colección "businesses", agregando el id del analista al arreglo "analistaIds".
- Retorna el documento actualizado del analista o errores apropiados.

Variables de entorno necesarias:
- DATABASE_URL: URL de conexión a MongoDB.
- MY_DATABASE_NAME: Nombre de la base de datos (por ejemplo, "vera-app").
"""

import os
import json
from bson import ObjectId# Importar para convertir cadenas a ObjectId
from pymongo import MongoClient
from utils.response import Response
from utils.serializable import serialize_document
from pymongo.errors import DuplicateKeyError



os.environ['DATABASE_URL'] = "mongodb+srv://admin:gJ66UV7FD1qs6jG0@valetest.8gw0zdt.mongodb.net"
os.environ['MY_DATABASE_NAME'] = "vera-app"
# Configurar variables de entorno (en producción, estas se definen en el entorno Lambda)
DATABASE_URL = os.environ.get("DATABASE_URL")
MY_DATABASE_NAME = os.environ.get("MY_DATABASE_NAME", "vera-app")

# Conexión global a MongoDB (se reutiliza entre invocaciones)
client = MongoClient(DATABASE_URL, serverSelectionTimeoutMS=5000)
db = client[MY_DATABASE_NAME]


def handler_function(event, context):
    """
    PATCH handler para asignar un negocio a un analista.
    Se espera:
      - event["pathParameters"]["id"]: el id del analista.
      - event["body"]: JSON con el campo "businessId".
    Se actualiza el documento del analista (agregando el businessId a assignedBusinessIds)
    y se actualiza el documento del negocio (agregando el analyst_id a analistaIds) de forma transaccional.
    """
    try:
        # Extraer el parámetro de ruta "id"
        path_params = event.get("pathParameters", {})
        analyst_id_str = path_params.get("id")
        if not analyst_id_str:
            return Response(
                status_code=400,
                body={"error": "Falta el parámetro de ruta 'id'"}
            ).to_dict()

        # Convertir analyst_id a ObjectId
        try:
            analyst_id = ObjectId(analyst_id_str)
        except Exception as conv_err:
            return Response(
                status_code=400,
                body={"error": "ID del analista no es válido", "details": str(conv_err)}
            ).to_dict()

        # Extraer y parsear el cuerpo de la solicitud (JSON)
        body = event.get("body")
        if not body:
            return Response(
                status_code=400,
                body={"error": "Falta el cuerpo de la solicitud"}
            ).to_dict()
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError:
                return Response(
                    status_code=400,
                    body={"error": "El cuerpo no es un JSON válido"}
                ).to_dict()

        businessId_str = body.get("businessId")
        if not businessId_str:
            return Response(
                status_code=400,
                body={"error": "Falta 'businessId' en el cuerpo"}
            ).to_dict()

        # Convertir businessId a ObjectId
        try:
            businessId = ObjectId(businessId_str)
        except Exception as conv_err:
            return Response(
                status_code=400,
                body={"error": "ID del negocio no es válido", "details": str(conv_err)}
            ).to_dict()

        # Iniciar una sesión para la transacción
        with client.start_session() as session:
            with session.start_transaction():
                # Actualizar el documento del analista: agregar businessId a assignedBusinessIds
                user_update_result = db["User"].update_one(
                    {"_id": analyst_id},
                    {"$addToSet": {"assignedBusinessIds": businessId}},
                    session=session
                )

                if user_update_result.matched_count == 0:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Analista no encontrado"}
                    ).to_dict()

                # Actualizar el documento del negocio: agregar analyst_id a analistaIds
                business_update_result = db["Business"].update_one(
                    {"_id": businessId},
                    {"$addToSet": {"analistaIds": analyst_id}},
                    session=session
                )
                if business_update_result.matched_count == 0:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Negocio no encontrado"}
                    ).to_dict()

                # Recuperar el documento actualizado del analista dentro de la sesión
                updated_analyst = db["User"].find_one(
                    {"_id": analyst_id},
                    session=session
                )
                if updated_analyst is None:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Analista no encontrado después de la actualización"}
                    ).to_dict()

        # Fuera de la transacción, se serializa el documento actualizado
        updated_analyst_serializer = serialize_document(updated_analyst)
        if "password" in updated_analyst_serializer:
            del updated_analyst_serializer["password"]

        return Response(
            status_code=200,
            body={"data": updated_analyst_serializer}
        ).to_dict()

    except DuplicateKeyError as e:
        # Si ocurre un error de clave duplicada (por ejemplo, por un username único), se maneja aquí
        return Response(
            status_code=400,
            body={"error": "El nombre de usuario ya está en uso", "details": str(e)}
        ).to_dict()

    except Exception as e:
        return Response(
            status_code=500,
            body={"error": "Error al asignar negocio", "details": str(e)}
        ).to_dict()


# Bloque opcional para pruebas locales
if __name__ == "__main__":
    # Crear un nuevo ObjectId


    # Convertir una cadena a ObjectId (asegúrate de que la cadena tenga 24 caracteres hexadecimales)
    # Simular un evento Lambda con parámetro de ruta y body JSON
    test_event = {
        "pathParameters": {"id": "67c8bec94ed8f7220d10a97e"},  # Reemplazar con un ObjectId válido en cadena
        "body": json.dumps({
            "businessId": "67c774ce1e7084d508ebd0fb"  # Reemplazar con un ObjectId válido en cadena
        })
    }
    # Ejecutar la función Lambda de prueba
    response = handler_function(test_event, {})
    print("Respuesta de la función Lambda:")
    print(response)
