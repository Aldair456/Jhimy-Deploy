import os
import json
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from bson import ObjectId
from utils.response import Response
from utils.serializable import serialize_document

# Solo local
os.environ['DATABASE_URL'] = "mongodb+srv://admin:gJ66UV7FD1qs6jG0@valetest.8gw0zdt.mongodb.net"
os.environ['MY_DATABASE_NAME'] = "vera-app"

# Conexión global a MongoDB (se reutiliza entre invocaciones)
client = MongoClient(os.environ['DATABASE_URL'], serverSelectionTimeoutMS=5000)
db = client[os.environ['MY_DATABASE_NAME']]



def handler_function(event, context):
    """
    PATCH handler para actualizar un analista.
    Se espera:
      - event["pathParameters"]["id"]: el id del analista.
      - event["body"]: JSON con los campos a actualizar (por ejemplo, name, email, username).
    Retorna el documento actualizado, incluyendo assignedBusinesses.
    """
    try:
        path_params = event.get("pathParameters", {})
        analyst_id = path_params.get("id")
        if not analyst_id:
            return Response(
                status_code=400,
                body={"error": "Falta el parámetro 'id'"}
            ).to_dict()

        body = event.get("body")
        if not body:
            return Response(
                status_code=400,
                body={"error": "Falta el cuerpo de la solicitud"}
            ).to_dict()

        if isinstance(body, str):
            body = json.loads(body)

        # Definir los campos a actualizar
        update_fields = {}
        for field in ["name", "email", "username"]:
            if field in body:
                update_fields[field] = body[field]

        if not update_fields:
            return Response(
                status_code=400,
                body={"error": "No hay campos para actualizar"}
            ).to_dict()

        # Actualizar el documento; usamos find_one_and_update para retornar el documento actualizado
        updated_analyst = db["User"].find_one_and_update(
            {"_id": ObjectId(analyst_id)},
            {"$set": update_fields},
            return_document=True  # Retorna el documento actualizado
        )
        if not updated_analyst:
            return Response(
                status_code=404,
                body={"error": "Usuario no encontrado"}
            ).to_dict()

        # Serializar el documento actualizado
        updated_analyst_serializer = serialize_document(updated_analyst)
        if "password" in updated_analyst_serializer:
            del updated_analyst_serializer["password"]

        return Response(
            status_code=200,
            body={"data": updated_analyst_serializer}
        ).to_dict()

    except DuplicateKeyError as e:
        return Response(
            status_code=400,
            body={"error": "El nombre de usuario ya está en uso", "details": str(e)}
        ).to_dict()

    except Exception as e:
        return Response(
            status_code=500,
            body={"error": "Error al actualizar analista", "details": str(e)}
        ).to_dict()

if __name__ == "__main__":
    event = {
        "pathParameters": {
            "id": "67c8a92b6f161af2d28af65c",
        },
        "body": json.dumps({"name": "Juan Pablo", "email": "juanpablo@utec.edu.pe", "username": "juanp"})
    }
    print(handler_function(event=event, context= None))