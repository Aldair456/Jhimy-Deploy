"""
Este módulo implementa una función Lambda para desasignar un negocio de un analista.

La función lambda_handler:
- Extrae el parámetro de ruta "id" (el id del analista) y el body JSON con "businessId".
- Convierte los ids (analyst y business) de cadena a ObjectId.
- Actualiza el documento del analista en la colección "users", eliminando el businessId del arreglo "assignedBusinessIds".
- Actualiza el documento del negocio en la colección "businesses", eliminando el id del analista del arreglo "analistaIds".
- Retorna el documento actualizado del analista o errores adecuados.

Variables de entorno necesarias:
- DATABASE_URL: URL de conexión a MongoDB.
- MY_DATABASE_NAME: Nombre de la base de datos (por ejemplo, "vera-app").
"""

import os
import json
from bson import ObjectId
from pymongo import MongoClient
from utils.response import Response
from utils.serializable import serialize_document

##
os.environ['DATABASE_URL'] = "mongodb+srv://admin:gJ66UV7FD1qs6jG0@valetest.8gw0zdt.mongodb.net"
os.environ['MY_DATABASE_NAME'] = "vera-app"

# Configurar variables de entorno (en producción se definen en el entorno Lambda)
DATABASE_URL = os.environ.get("DATABASE_URL")
MY_DATABASE_NAME = os.environ.get("MY_DATABASE_NAME", "vera-app")

# Conexión global a MongoDB (se reutiliza entre invocaciones)
client = MongoClient(DATABASE_URL, serverSelectionTimeoutMS=5000)
db = client[MY_DATABASE_NAME]


def handler_function(event, context):
    try:
        # Extraer el parámetro de ruta "id" (analyst id)
        path_params = event.get("pathParameters", {})
        analyst_id_str = path_params.get("id")
        if not analyst_id_str:
            return Response(
                status_code=400,
                body={"error": "Falta el parámetro de ruta 'id'"}
            ).to_dict()
        try:
            analyst_id = ObjectId(analyst_id_str)
        except Exception as conv_err:
            return Response(
                status_code=400,
                body={"error": "ID del analista no es válido", "details": str(conv_err)}
            ).to_dict()

        # Extraer y parsear el cuerpo de la solicitud (JSON)
        body = event.get("body")
        if not body:
            return Response(
                status_code=400,
                body={"error": "Falta el cuerpo de la solicitud"}
            ).to_dict()
        if isinstance(body, str):
            try:
                body = json.loads(body)
            except json.JSONDecodeError as e:
                return Response(
                    status_code=400,
                    body={"error": "El cuerpo no es un JSON válido", "details": str(e)}
                ).to_dict()

        business_id_str = body.get("businessId")
        if not business_id_str:
            return Response(
                status_code=400,
                body={"error": "Falta 'businessId' en el cuerpo"}
            ).to_dict()
        try:
            business_id = ObjectId(business_id_str)
        except Exception as conv_err:
            return Response(
                status_code=400,
                body={"error": "ID del negocio no es válido", "details": str(conv_err)}
            ).to_dict()

        # Iniciar una sesión para la transacción
        with client.start_session() as session:
            with session.start_transaction():
                # Recuperar el documento del analista y su arreglo assignedBusinessIds
                analyst = db["User"].find_one(
                    {"_id": analyst_id},
                    {"assignedBusinessIds": 1},
                    session=session
                )
                if not analyst:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Analista no encontrado"}
                    ).to_dict()
                current_assigned = analyst.get("assignedBusinessIds", [])
                # Filtrar para eliminar el businessId a desasignar
                new_assigned = [bid for bid in current_assigned if bid != business_id]

                # Actualizar el documento del analista
                user_update_result = db["User"].update_one(
                    {"_id": analyst_id},
                    {"$set": {"assignedBusinessIds": new_assigned}},
                    session=session
                )
                if user_update_result.matched_count == 0:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Analista no encontrado durante la actualización"}
                    ).to_dict()

                # Actualizar el documento del negocio: eliminar el id del analista del arreglo analistaIds
                business = db["Business"].find_one(
                    {"_id": business_id},
                    {"analistaIds": 1},
                    session=session
                )
                if not business:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Negocio no encontrado"}
                    ).to_dict()
                current_analyst_ids = business.get("analistaIds", [])
                new_analyst_ids = [aid for aid in current_analyst_ids if aid != analyst_id]
                business_update_result = db["Business"].update_one(
                    {"_id": business_id},
                    {"$set": {"analistaIds": new_analyst_ids}},
                    session=session
                )
                if business_update_result.matched_count == 0:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Negocio no encontrado durante la actualización"}
                    ).to_dict()

                # Recuperar el documento actualizado del analista dentro de la transacción
                updated_analyst = db["User"].find_one({"_id": analyst_id}, session=session)
                if not updated_analyst:
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Analista no encontrado después de la actualización"}
                    ).to_dict()

        # Fuera de la transacción, se serializa el documento actualizado
        updated_analyst_serializer = serialize_document(updated_analyst)
        if "password" in updated_analyst_serializer:
            del updated_analyst_serializer["password"]

        return Response(
            status_code=200,
            body={"data": updated_analyst_serializer}
        ).to_dict()

    except Exception as e:
        return Response(
            status_code=500,
            body={"error": "Error al desasignar negocio", "details": str(e)}
        ).to_dict()

# Bloque opcional para pruebas locales
if __name__ == "__main__":
    # Simular un evento Lambda con parámetro de ruta y body JSON.
    # Reemplaza los valores con ObjectIds válidos según tu base de datos.
    test_event = {
        "pathParameters": {"id": "67c8bec94ed8f7220d10a97e"},  # Reemplazar con un ObjectId válido en cadena
        "body": json.dumps({
            "businessId": "67c774ce1e7084d508ebd0fb"  # Reemplazar con un ObjectId válido en cadena
        })
    }
    response = handler_function(test_event, {})
    print("Respuesta de la función Lambda:")
    print(response)
