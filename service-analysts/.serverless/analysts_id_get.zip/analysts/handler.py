"""
Este módulo implementa una función Lambda para obtener la lista de usuarios analistas.

La función lambda_handler:
- Extrae el token JWT de la cabecera "Authorization" (formato "Bearer <token>").
- Decodifica el token para obtener la sesión del usuario.
- Verifica que la sesión exista y que el usuario tenga rol "ADMIN".
- Extrae el evaluatorId de la sesión y consulta en MongoDB todos los usuarios con rol "ANALYST" y ese evaluatorId.
- Devuelve la lista de analistas o errores apropiados en caso de fallo.

Variables de entorno necesarias:
- DATABASE_URL: URL de conexión a MongoDB.
- JWT_SECRET: Clave secreta para decodificar el token JWT.
- MY_DATABASE_NAME: Nombre de la base de datos (por ejemplo, "vera-app").
"""

import os
from bson import  ObjectId
from pymongo import MongoClient
import jwt  # Asegúrate de tener instalado PyJWT
from utils.response import Response
from utils.serializable import serialize_document

#solo local
os.environ['DATABASE_URL'] = "mongodb+srv://admin:gJ66UV7FD1qs6jG0@valetest.8gw0zdt.mongodb.net"
os.environ['MY_DATABASE_NAME'] = "vera-app"

# Configuración de variables de entorno (en producción se definen en el entorno Lambda)
DATABASE_URL = os.environ.get("DATABASE_URL")
JWT_SECRET = os.environ.get("JWT_SECRET", "supersecret")
MY_DATABASE_NAME = os.environ.get("MY_DATABASE_NAME", "vera-app")

# Conexión global a MongoDB (se reutiliza entre invocaciones)
client = MongoClient(DATABASE_URL, serverSelectionTimeoutMS=5000)
db = client[MY_DATABASE_NAME]


def handler_function(event, context):
    """
    Función Lambda para obtener analistas.

    Parámetros:
        event (dict): Objeto de evento que contiene la solicitud HTTP. Se espera:
                      - headers: Debe incluir "Authorization" con el token JWT (formato "Bearer <token>").
        context (object): Información del contexto de ejecución de Lambda.

    Retorna:
        dict: Respuesta HTTP en formato JSON.
              - Código 200: Retorna la lista de analistas.
              - Código 401: Si no se encuentra la sesión o el usuario no tiene rol ADMIN.
              - Código 404: Si no se encuentran analistas.
              - Código 500: Error interno del servidor.
    """
    try:
        # Extraer y validar el token JWT desde los headers
        headers = event.get("headers", {})
        auth_header = headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return Response(
                status_code=401,
                body={"error": "Authorization header missing or malformed"}
            ).to_dict()
        token = auth_header.split(" ", 1)[1]

        try:
            # Decodificar el token JWT
            session = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        except Exception as e:
            return Response(
                status_code=401,
                body={"error": "Token inválido", "details": str(e)}
            ).to_dict()

        # Verificar que el usuario autenticado tenga rol "ADMIN"
        if session.get("role") != "ADMIN":
            return Response(
                status_code=401,
                body={"error": "Unauthorized: se requiere rol ADMIN"}
            ).to_dict()

        evaluatorId = session.get("evaluatorId")
        if not evaluatorId:
            return Response(
                status_code=400,
                body={"error": "Evaluator ID no encontrado en la sesión"}
            ).to_dict()

        # Consultar en la colección "users" los analistas asociados al evaluatorId
        cursor = db["User"].find({
            "role": "ANALYST",
            "evaluatorId": ObjectId(evaluatorId)
        })

        analysts = list(cursor)


        if not analysts:
            return Response(
                status_code=404,
                body={"error": "Analyst not found"}
            ).to_dict()

        # Convertir los ObjectIds y datetime a cadenas para la serialización JSON
        analysts_serializer = serialize_document(analysts)
        for analyst in analysts_serializer: del analyst["password"]

        return Response(
            status_code=200,
            body={"analysts": analysts_serializer}
        ).to_dict()


    except Exception as e:
        return Response(
            status_code=500,
            body={"error": "Internal server error", "details": str(e)}
        ).to_dict()

# Bloque de prueba local
if __name__ == "__main__":
    test_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY3OWQwNTA4YzQzNGQ3YzJjOTNiM2EwZCIsInVzZXJuYW1lIjoicmJvbmlmYXoiLCJyb2xlIjoiQURNSU4iLCJldmFsdWF0b3JJZCI6IjY3OWQwNGQyYzQzNGQ3YzJjOTNiM2EwOSIsImV4cCI6MTc0Mzc1NTc0MH0.YSTrZc-3wsQkIeHFR86lXZyN1kZVvUWFJVPwGGfIxXg"
    test_headers = {
        "Authorization": f"Bearer {test_token}"
    }

    # Simular un evento para la función Lambda
    # En este caso, solo necesitamos headers ya que es una operación GET sin body
    event_test = {
        "headers": test_headers
    }

    # Ejecutar la función Lambda de prueba
    response = handler_function(event_test, {})
    print("Respuesta de la función Lambda:")
    print(response)
