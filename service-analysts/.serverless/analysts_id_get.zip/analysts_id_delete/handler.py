import os
from pymongo import MongoClient
from bson import ObjectId
from utils.response import Response

# Solo local
os.environ['DATABASE_URL'] = "mongodb+srv://admin:gJ66UV7FD1qs6jG0@valetest.8gw0zdt.mongodb.net"
os.environ['MY_DATABASE_NAME'] = "vera-app"

# Conexión global a MongoDB (se reutiliza entre invocaciones)
client = MongoClient(os.environ['DATABASE_URL'], serverSelectionTimeoutMS=5000)
db = client[os.environ['MY_DATABASE_NAME']]

# Clave secreta para decodificar y firmar el token JWT
SECRET_KEY = os.environ.get("JWT_SECRET", "supersecret")


def handler_function(event, context):
    """
    DELETE handler para eliminar un analista de la colección "User" y,
    de forma transaccional, eliminar su id de la lista de usuarios en la colección "bunesss".
    Se espera que event["pathParameters"]["id"] contenga el id del analista.
    La eliminación se realiza solo si el rol del usuario es 'ANALYST'.
    """
    try:
        path_params = event.get("pathParameters", {})
        analyst_id = path_params.get("id")

        if not analyst_id:
            return Response(
                status_code=400,
                body={"error": "Falta el parámetro 'id'"}
            ).to_dict()

        # Inicia una sesión para la transacción
        with client.start_session() as session:
            with session.start_transaction():
                # Elimina el documento de la colección "User" para el rol ANALYST
                user_result = db["User"].delete_one(
                    {"_id": ObjectId(analyst_id), "role": "ANALYST"},
                    session=session
                )
                if user_result.deleted_count == 0:
                    # Si no se encontró el usuario o no cumple el rol, aborta la transacción
                    session.abort_transaction()
                    return Response(
                        status_code=404,
                        body={"error": "Usuario no encontrado o no es un ANALYST"}
                    ).to_dict()

                # Remueve el ID del usuario de la lista "users" en la colección "bunesss"
                db["Business"].update_many(
                    {"analistaIds": ObjectId(analyst_id)},
                    {"$pull": {"analistaIds": ObjectId(analyst_id)}},
                    session=session
                )

        return Response(
            status_code=204,
            body={"success": True}
        ).to_dict()
    except Exception as e:
        return Response(
            status_code=500,
            body={"error": "Error al eliminar analista", "details": str(e)}
        ).to_dict()

if __name__ == "__main__":
    event = {
        "pathParameters": {
            "id": "67c7555edd079a6ee23e67b6",
        }
    }
    print(handler_function(event=event, context={}))